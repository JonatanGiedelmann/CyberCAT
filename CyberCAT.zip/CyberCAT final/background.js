chrome.runtime.onInstalled.addListener(() => {
    console.log('HTTPS Checker extension installed');
  });
  